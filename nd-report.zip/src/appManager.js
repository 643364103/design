/**
 * Created by Administrator on 2016/11/28.
 */

import {eventBus, eventKey, flowType} from 'common/eventBus'

let vue
let flows = [flowType.LOADING, flowType.BIGENENT, flowType.SCENE]

let flowManager = {
  init: (v) => {
    vue = v
  },
  goNext: (type) => {
    let i = flows.indexOf(type)
    if (i === flows.length - 1) {
      return false
    }
    let nextFlow = flows[i + 1]

    vue.$router.push({name: nextFlow})
    return true
  }
}

// 监听流程完成事件
eventBus.$on(eventKey.COMPLETE, (type) => {
  flowManager.goNext(type)
})

export default {init: flowManager.init}
