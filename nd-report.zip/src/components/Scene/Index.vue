<template>
  <div>
     {{msg}}
  </div>
</template>

<script>
// import GyroControls from './GyroControls'
export default {
  data () {
    return {
      msg: 'scene'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
