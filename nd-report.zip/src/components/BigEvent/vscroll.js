var rAF = window.requestAnimationFrame ||
  window.webkitRequestAnimationFrame ||
  window.mozRequestAnimationFrame ||
  window.oRequestAnimationFrame ||
  window.msRequestAnimationFrame ||
  function (callback) {
    window.setTimeout(callback, 1000 / 60)
  }

var utils = (function () {
  var me = {}

  me.getTime = Date.now || function getTime () {
    return new Date().getTime()
  }
  me.extend = function (target, obj) {
    for (var i in obj) {
      target[i] = obj[i]
    }
  }
  me.addEvent = function (el, type, fn, capture) {
    el.addEventListener(type, fn, !!capture)
  }
  me.removeEvent = function (el, type, fn, capture) {
    el.removeEventListener(type, fn, !!capture)
  }
  me.momentum = function (current, start, time, lowerMargin, wrapperSize, deceleration) {
    var distance = current - start
    var speed = Math.abs(distance) / time
    var destination
    var duration

    deceleration = deceleration === undefined ? 0.0006 : deceleration

    destination = current + (speed * speed) / (2 * deceleration) * (distance < 0 ? -1 : 1)
    duration = speed / deceleration

    if (destination < lowerMargin) {
      destination = wrapperSize ? lowerMargin - (wrapperSize / 2.5 * (speed / 8)) : lowerMargin
      distance = Math.abs(destination - current)
      duration = distance / speed
    } else if (destination > 0) {
      destination = wrapperSize ? wrapperSize / 2.5 * (speed / 8) : 0
      distance = Math.abs(current) + destination
      duration = distance / speed
    }

    return {
      destination: Math.round(destination),
      duration: duration
    }
  }
  me.extend(me.ease = {}, {
    quadratic: {
      style: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
      fn: function (k) {
        return k * (2 - k)
      }
    },
    circular: {
      style: 'cubic-bezier(0.1, 0.57, 0.1, 1)',
      fn: function (k) {
        return Math.sqrt(1 - (--k * k))
      }
    }
  })

  return me
})()

var VScroll = function (el, options) {
  this.wrapper = typeof el === 'string' ? document.querySelector(el) : el
  this.scroller = this.wrapper.children[0]
  this.scrollerStyle = this.scroller.style
  this.scrollerStyle.position = 'relative'
  this.options = {
    mouseWheelSpeed: 20,
    bounceTime: 600,
    bounce: true,
    deceleration: 0.002
  }
  for (var i in options) {
    this.options[i] = options[i]
  }
  this.y = 0
  this._init()
  this.refresh()
  this.enable()
}
VScroll.prototype = {
  _init: function () {
    this._initEvents()
  },

  destroy: function () {
    this._initEvents(true)
  },

  _initEvents: function (remove) {
    var eventType = remove ? utils.removeEvent : utils.addEvent
    eventType(this.wrapper, 'mousedown', this)
    eventType(document, 'mousemove', this)
    eventType(document, 'mouseup', this)

    eventType(this.wrapper, 'touchstart', this)
    eventType(document, 'touchmove', this)
    eventType(document, 'touchend', this)

    eventType(this.wrapper, 'wheel', this)
    eventType(this.wrapper, 'mousewheel', this)
    eventType(this.wrapper, 'DOMMouseScroll', this)
  },

  _start: function (e) {
    if (!this.enabled) {
      return
    }
    var point = e.touches ? e.touches[0] : e
    this.startY = this.y
    this.pointY = point.pageY
    this.startTime = utils.getTime()
    this.isMove = true
    this.isAnimating = false
  },

  _move: function (e) {
    if (!this.enabled) {
      return
    }
    if (this.isMove) {
      var point = e.touches ? e.touches[0] : e
      var deltaY = point.pageY - this.pointY
      var newY = deltaY + this.startY
      if (newY > 0 || newY < this.maxScrollY) {
        newY = this.options.bounce ? deltaY / 3 + this.startY : newY > 0 ? 0 : this.maxScrollY
      }
      this._translate(newY)
    }
  },

  _end: function (e) {
    if (!this.enabled) {
      return
    }
    this.isMove = false
    var momentumY
    var duration = utils.getTime() - this.startTime
    var newY = Math.round(this.y)
    var time = 0
    var easing = ''

    if (this.resetPosition(this.options.bounceTime)) {
      return
    }

    this.scrollTo(newY)
    if (duration < 260) {
      momentumY = utils.momentum(this.y, this.startY, duration, this.maxScrollY, this.options.bounce ? this.wrapperHeight : 0, this.options.deceleration)
      newY = momentumY.destination
      time = momentumY.duration
      if (newY !== this.y) {
        if (newY > 0 || newY < this.maxScrollY) {
          easing = utils.ease.quadratic
        }
      }
      this.scrollTo(newY, time, easing)
    }
  },

  _wheel: function (e) {
    if (!this.enabled) {
      return
    }

    e.preventDefault()

    var wheelDeltaY

    if ('deltaX' in e) {
      if (e.deltaMode === 1) {
        wheelDeltaY = -e.deltaY * this.options.mouseWheelSpeed
      } else {
        wheelDeltaY = -e.deltaY
      }
    } else if ('wheelDeltaX' in e) {
      wheelDeltaY = e.wheelDeltaY / 120 * this.options.mouseWheelSpeed
    } else if ('wheelDelta' in e) {
      wheelDeltaY = e.wheelDelta / 120 * this.options.mouseWheelSpeed
    } else if ('detail' in e) {
      wheelDeltaY = -e.detail / 3 * this.options.mouseWheelSpeed
    } else {
      return
    }

    var newY = this.y + Math.round(wheelDeltaY * 0.9)
    if (newY > 0) {
      newY = 0
    } else if (newY < this.maxScrollY) {
      newY = this.maxScrollY
    }

    this.scrollTo(newY, 100)
  },

  disable: function () {
    this.enabled = false
  },

  enable: function () {
    this.enabled = true
  },

  resetPosition: function (time) {
    var y = this.y

    time = time || 0

    if (this.y > 0) {
      y = 0
    } else if (this.y < this.maxScrollY) {
      y = this.maxScrollY
    }

    if (y === this.y) {
      return false
    }

    this.scrollTo(y, time, utils.ease.circular)

    return true
  },

  refresh: function () {
    this.wrapperHeight = this.wrapper.clientHeight
    this.scrollerHeight = this.scroller.offsetHeight
    this.maxScrollY = this.wrapperHeight - this.scrollerHeight
    this.resetPosition()
  },

  scrollTo: function (y, time, easing) {
    easing = easing || utils.ease.circular
    if (!time) {
      this._translate(y)
    } else {
      this._animate(y, time, easing.fn)
    }
  },

  _animate: function (destY, duration, easingFn) {
    var that = this
    var startY = this.y
    var startTime = utils.getTime()
    var destTime = startTime + duration

    function step () {
      var now = utils.getTime()
      var newY
      var easing

      if (now >= destTime) {
        that.isAnimating = false
        that._translate(destY)
        that.resetPosition(that.options.bounceTime)
        return
      }

      now = (now - startTime) / duration
      easing = easingFn(now)
      newY = (destY - startY) * easing + startY
      that._translate(newY)

      if (that.isAnimating) {
        rAF(step)
      }
    }

    this.isAnimating = true
    step()
  },

  _translate: function (y) {
    y = Math.round(y)
    this.scrollerStyle.top = y + 'px'
    this.y = y
  },

  /*
   interface EventListener {
   void  handleEvent (Event evt)
   }
   */
  handleEvent: function (e) {
    switch (e.type) {
      case 'touchstart':
      case 'mousedown':
        this._start(e)
        break
      case 'touchmove':
      case 'mousemove':
        this._move(e)
        break
      case 'touchend':
      case 'mouseup':
        this._end(e)
        break
      case 'wheel':
      case 'mousewheel':
      case 'DOMMouseScroll':
        this._wheel(e)
        break
    }
  }
}
export default VScroll
