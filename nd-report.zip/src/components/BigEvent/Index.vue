<template>
  <div>
     <p>{{msg}}</p>
    <div class="wrapper">
      <ul>
        <li>1</li>
        <li>2</li>
        <li>3</li>
        <li>4</li>
        <li>5</li>
        <li>6</li>
        <li>7</li>
        <li>8</li>
        <li>9</li>
        <li>10</li>
        <li>11</li>
        <li>12</li>
        <li>13</li>
        <li>14</li>
        <li>15</li>
      </ul>
    </div>
  </div>
</template>

<script>
  import Vscroll from './vscroll.js'
  export default {
    data () {
      return {
        msg: 'bigEvent'
      }
    },
    mounted () {
      var scroll = new Vscroll('.wrapper')
      scroll.enable()
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .wrapper,
  ul,
  li{
    margin: 0;
    padding: 0;
  }
  .wrapper {
    width: 500px;
    height: 600px;
    border: 1px solid #CCC;
    overflow: hidden;
    margin: 20px auto;
    -moz-user-select:none;/*火狐*/
    -webkit-user-select:none;/*webkit浏览器*/
    -ms-user-select:none;/*IE10*/
    -khtml-user-select:none;/*早期浏览器*/
    user-select:none;
  }
  ul {
    list-style: none;
    padding: 10px 0;
  }
  li {
    height: 100px;
    margin: 10px;
    border: 1px solid #CCC
  }
  li:first-child {
    margin-top: 0;
  }
  li:last-child {
    margin-bottom: 0;
  }
</style>
