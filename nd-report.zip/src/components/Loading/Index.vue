<template src="./index.html">
</template>

<script>
  import DataService from '../../services/dataService.js'
  import {eventBus, eventKey, flowType} from 'common/eventBus'

  let loadInfo = {
    msg: 'loading',
    num: 0
  }
  function onComplete () {
    loadInfo.msg = 'onComplete'
    loadInfo.num = 99
  }
  function onFail () {
    loadInfo.msg = 'onFail'
    loadInfo.num = 0
  }
  var dataService = new DataService(onComplete, onFail)
  dataService.init()
  export default {
    data () {
      return loadInfo
    },

    mounted: function () {
      var that = this
      var interval = setInterval(function () {
        that.num++
        if (that.num > 99) {
          clearInterval(interval)
        }
      }, 100)
    },

    methods: {
      goEvent () {
        eventBus.$emit(eventKey.COMPLETE, flowType.LOADING)
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .background{
    width: 200px;
    height: 200px;
    display: block;
    margin: 0 auto
  }
  
</style>
