var commonData = {
  moduleSkin: '',
  moduleSenceBg: '',
  moduleCenterPosition: {x: 0, y: 0, z: 0},
  moduleHotspot: [],
  sysData: {}
}

export default commonData
