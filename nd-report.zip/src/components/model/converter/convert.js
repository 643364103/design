import commonData from '../commondata'
import hotSpot from '../hotspot'
import sysData from '../sysdata'

var Converter = function () {}

Converter.convert = function (dataObj) {
  Object.assign(commonData, dataObj.commonData)
  Object.assign(sysData, dataObj.commonData.sysData)
  commonData.sysData = sysData
  for (let tempHotSpot of commonData.moduleHotspot) {
    tempHotSpot.userData = dataObj.userData
    tempHotSpot.getUserDataByType = hotSpot.getUserDataByType
  }
  commonData.userData = dataObj.userData
  return commonData
}

export default Converter
