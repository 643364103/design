var hotspot = {
  moduleMainImage: '',
  modulePosition: {x: 0, y: 0, z: 0},
  moduleText: '',
  moduleDialogType: 0,
  getUserDataByType: function (typeId) {
    return {}
  }
}
export default hotspot
