var sysData = {
  RUNTIME: 0,
  USER: {}
}
export default sysData
