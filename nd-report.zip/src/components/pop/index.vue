<template src="./index.html">
</template>
<style scoped>

</style>
<script>
 var animate = require('node/animateplus/animate.min.js')

 export default {
   data () {
     return 'pic'
   },
   mounted () {
     console.log(this.$el.getElementsByClassName('ndUi-pop-dialog')[0])
     var that = this
     console.log(animate)
     function end (el) {
       // el[0].style = ''
       animate({
         el: that.$el.getElementsByClassName('ui-com-close')[0],
         duration: 1,
         opacity: 1
       })
     }
     animate({
       el: this.$el.getElementsByClassName('ndUi-pop-dialog'),
       duration: 5000,
       scaleX: [0.1, 1],
       scaleY: [0.1, 1],
       complete: end
     })
   },
   methods: {
     close: function (event) {
       this.$router.push('/')
       console.log('close')
     }
   }
 }
</script>
