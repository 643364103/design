/**
 * Created by Administrator on 2016/11/28.
 */

import Vue from 'vue'

const bus = new Vue()

// 简单事件总线，如果需要管理复杂组件状态，建议使用vuex来处理
export const eventBus = bus

// 事件key
export const eventKey = {
  COMPLETE: 'COMPLETE'
}

// 事件key
export const flowType = {
  LOADING: 'LOADING',
  BIGENENT: 'BIGENENT',
  SCENE: 'SCENE',
  POP: 'POP'
}
