import xhr from './xhr/'
import Converter from 'components/model/converter/convert.js'

//
/* get 获取资源
 xhr({ url })
 */

/* post 新增
 xhr({
 method: 'post',
 url: '/msg',
 body: msgBody
 })
 */

/*  put  修改
 xhr({
 method: 'put',
 url: '/msg',
 body: msgBody
 }) */

/*  delete  删除
 xhr({
 method: 'delete',
 url: `/msg/${msgId}`
 }) */
/**
 * 对应后端数据的  所有 API
 */
function DataService (successCallback, errorCallback) {
  this.successCallback = successCallback
  this.errorCallback = errorCallback
  this.configApi = '/commondata'
  this.userApi = '/userdata'
}
DataService.prototype = {
  init () {
    var that = this
    var p1 = xhr({url: this.configApi})
    var p2 = xhr({url: this.userApi})
    var p3 = new Promise(function (resolve) {
      setTimeout(function () {
        resolve()
      }, 2000)
    })
    Promise.all([p1, p2, p3]).then((response) => {
      var commonData = response[0][0]
      var userData = response[1][0]
      window.commonData = Converter.convert({commonData, userData})
      that.successCallback()
    }, (response) => {
      that.errorCallback()
    })
  }
}

// 实例化后再导出
export default DataService
