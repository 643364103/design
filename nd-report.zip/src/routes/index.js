import Vue from 'vue'
import VueRouter from 'vue-router'

import Loading from 'components/Loading/'
import BigEvent from 'components/BigEvent/'
import Scene from 'components/Scene/'
import {flowType} from 'common/eventBus'
import pop from 'components/pop'

Vue.use(VueRouter)

const router = new VueRouter({
  mode: 'history',
  base: __dirname,
  routes: [
    { name: flowType.LOADING, path: '/', component: Loading },
    { name: flowType.LOADING, path: '/loading', component: Loading },
    { name: flowType.BIGENENT, path: '/event', component: BigEvent },
    { name: flowType.SCENE, path: '/scene', component: Scene },
    { name: flowType.POP, path: '/pop', component: pop }
  ]
})

export default router
