// 不同模块应代码分离

import Loading from './components/Loading/'
import BigEvent from './components/BigEvent/'
import Scene from './components/Scene/'

const router = new VueRouter({
  mode: 'history',
  base: __dirname,
  routes: [
    {path: '/', component: Loading},
    {path: '/loading', component: Loading},
    {path: '/event', component: BigEvent},
    {path: '/scene', component: Scene}
  ]
})

export default router
