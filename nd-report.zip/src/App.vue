<template>
  <div id="app" class="ui-yearProject">
    <ul>
      <li>
        <router-link to="/loading">Flow1</router-link>
      </li>
      <li>
        <router-link to="/event">Flow2</router-link>
      </li>
      <li>
        <router-link to="/pop">Flow3</router-link>
      </li>
    </ul>
    <router-view></router-view>
  </div>
</template>

<script>
  require('assets/css/style.css')

  export default {
    name: 'app',
    components: {
    },
    data () {
      return {
        msg: ''
      }
    }
  }
</script>

<style>
  #app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
  }
</style>
