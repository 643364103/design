import Vue from 'vue'
import App from './App'
import router from './routes/'
import appManager from './appManager'

/* eslint-disable no-new */
const vue = new Vue({
  el: '#app',
  router,
  // replace the content of <div id="app"></div> with App
  render: h => h(App)
})

appManager.init(vue)
