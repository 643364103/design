 const faker = require('faker')
 module.exports = function() {
   let data = {
     'commonData': [
       {
         moduleSkin: faker.image.image(),
         moduleSenceBg: '',
         moduleCenterPosition: {x: 0, y: 0, z: 0},
         moduleHotspot: [{moduleText: 't1'}, {moduleText: 't2'}],
         sysData: {USER: {id: 123456, kickname: 'zzz'}}
       }
     ],
     'userData': [
       {
         events: [],
         message: ''
       }
     ]
   }
   return data
 }
