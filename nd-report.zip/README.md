# nd-report

> 99u 年报项目

## 项目相关
1. vue 官方文档 https://vuefe.cn/guide/
1. 脚手架里包括了e2e,unit
1. 支持es6（建议使用es6）
1. vue 调试组件 https://github.com/vuejs/vue-devtools

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# runlint
npm run lint

# run unit tests
npm run unit

# run e2e tests
npm run e2e

# run all tests
npm test


```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

#install chromedriver 失败可以尝试下面
npm install chromedriver --chromedriver_cdnurl=http://cdn.npm.taobao.org/dist/chromedriver